import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData lightTheme = ThemeData(
    primaryColor: Colors.deepPurple,
    scaffoldBackgroundColor: Colors.transparent,
    fontFamily: 'Roboto',
    switchTheme: SwitchThemeData(
      thumbColor: MaterialStateProperty.all(Colors.pinkAccent),
    ),
  );
}
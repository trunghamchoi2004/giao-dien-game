class SettingsModel {
  bool soundOn;
  bool autoSave;
  double volume;
  int highScore;

  SettingsModel({
    this.soundOn = true,
    this.autoSave = false,
    this.volume = 0.3,
    this.highScore = 3500,
  });
}
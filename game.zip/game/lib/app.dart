import 'package:flutter/material.dart';
import 'screens/home_page.dart';
import 'themes/app_theme.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Game Settings',
      theme: AppTheme.lightTheme,
      home: HomePage(),
    );
  }
}